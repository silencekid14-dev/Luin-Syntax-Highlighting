# Luin syntax highlighting for VS Code

Highlights `.sx` files (Luin v2.6): keywords, `fn`/`cls` names, f-strings with {interpolation},
comments (#), numbers, builtins (show, ask, get, ...), modules (math, gui, ...), operators.

## Install
1. Copy this whole folder to your VS Code extensions folder, named `local.luin-sx-0.1.0`:
   - Windows: %USERPROFILE%\.vscode\extensions\
   - Linux / macOS: ~/.vscode/extensions/
2. Fully restart VS Code.
3. Open any .sx file. The language shown bottom-right should be "Luin".

## Quick test without installing
Open this folder in VS Code and press F5; a second window opens with the extension active.
